#include "userprog/syscall.h"
#include <stdio.h>
#include <syscall-nr.h>
#include "threads/interrupt.h"
#include "threads/thread.h"
#include "threads/vaddr.h"

static void syscall_handler (struct intr_frame *)	;

void
syscall_init (void) 
{
  intr_register_int (0x30, 3, INTR_ON, syscall_handler, "syscall");
}

static void
syscall_handler (struct intr_frame *f) 
{ 
  switch(*(uint32_t *)(f->esp)) {
	case SYS_HALT :
		halt();
		break;
	case SYS_EXIT :
		if(!is_user_vaddr(f->esp + 4))	exit(-1);
		exit(*(uint32_t *)(f->esp + 4));
		break;
	case SYS_EXEC :
		if(!is_user_vaddr(f->esp + 4))	exit(-1);
		f->eax = exec((const char *)*(uint32_t *)(f->esp + 4));
		break;
	case SYS_WAIT :
		if(!is_user_vaddr(f->esp + 4))	exit(-1);
		f->eax = wait((pid_t)*(uint32_t *)(f->esp + 4));
		break;
	case SYS_CREATE : break;
	case SYS_REMOVE : break;
	case SYS_OPEN : break;
	case SYS_FILESIZE : break;
	case SYS_READ :
		if(!is_user_vaddr(f->esp + 4))	exit(-1);
		if(!is_user_vaddr(f->esp + 8))	exit(-1);
		if(!is_user_vaddr(f->esp + 12))	exit(-1);
		read((int)*(uint32_t *)(f->esp+4), (void *)*(uint32_t *)(f->esp + 8), (unsigned)*((uint32_t *)(f->esp + 8)));
		break;
	case SYS_WRITE :
		if(!is_user_vaddr(f->esp + 4)) exit(-1);
		if(!is_user_vaddr(f->esp + 8)) exit(-1);
		if(!is_user_vaddr(f->esp + 12)) exit(-1);
		write((int)*(uint32_t *)(f->esp+4), (void *)*(uint32_t *)(f->esp + 8), (unsigned)*((uint32_t *)(f->esp + 12)));
		break;
	case SYS_SEEK : break;
	case SYS_TELL : break;
	case SYS_CLOSE : break;
	case SYS_FIBO : 
		if(!is_user_vaddr(f->esp+4)) exit(-1);
		f->eax = fibo(*(int*)(f->esp+4));
		break;
	case SYS_SUM :
		if(!is_user_vaddr(f->esp+8) || !is_user_vaddr(f->esp+12)) exit(-1);
		if(!is_user_vaddr(f->esp+16) || !is_user_vaddr(f->esp+4)) exit(-1);
		f->eax = sum(*(int*)(f->esp+4), *(int*)(f->esp+8), *(int*)(f->esp+12), *(int*)(f->esp+16));
  }
	

//  printf ("system call!\n");
//  thread_exit ();
}

void check_func (bool flag, int num, const char* str) {
	if(flag == true) {
		printf("%s : %d\n", str, num);
		exit(-1);
	}
}

void halt (void) {
	shutdown_power_off();
}

void exit (int status) {
	printf("%s: exit(%d)\n", thread_name(), status);
	thread_current() -> exit_status = status;
	thread_exit();
}

pid_t exec (const char *cmd_line) {
	return process_execute(cmd_line);
}

int wait (pid_t pid) {
	return process_wait(pid);
}

int read (int fd, void* buffer, unsigned size) {
	int i;
	if (fd == 0) {
		for ( i = 0; i < size; i++) {
			check_func(false, 1, "check");
			if(((char *)buffer)[i] == '\0') {
				break;
			}
		}
	}
	return i;
}

int write (int fd, const void *buffer, unsigned size) {
	if (fd == 1) {
		check_func(false, 1, "check");
		putbuf(buffer, size);
		return size;
	}
	return -1;
}

int fibo(int n) {
	if(n<=2) return 1;
	else return fibo(n-1) + fibo(n-2);
}

int sum(int n1, int n2, int n3, int n4) {
	return n1 + n2 + n3 + n4;
}



