#include <stdio.h>
#include <syscall.h>


int main(int argc, char **argv) {

	int n1 = atoi(argv[1]);
	
	int n2 = atoi(argv[2]);
	int n3 = atoi(argv[3]);
	int n4 = atoi(argv[4]);

	printf("%d ", fibo(n1));
	printf("%d ", sum(n1, n2, n3, n4));	
	
	return EXIT_SUCCESS;
}



