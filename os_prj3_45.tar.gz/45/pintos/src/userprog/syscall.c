#include "userprog/syscall.h"
#include <stdio.h>
#include <syscall-nr.h>
#include "threads/interrupt.h"
#include "threads/thread.h"
#include "threads/vaddr.h"
#include "filesys/file.h"
#include "filesys/off_t.h"
#include "filesys/filesys.h"
#include "threads/synch.h"

static void syscall_handler (struct intr_frame *)	;
bool create(const char* file, unsigned initial_size);
bool remove(const char* file);
int open(const char* file);
int filesize(int fd);
int read(int fd, void* buffer, unsigned size);
int write(int fd, const void* buffer, unsigned size);
void seek(int fd, unsigned position);
unsigned tell(int fd);
void close(int fd);

struct semaphore mutex, wrt;
int readcount;

struct file
   {
     struct inode *inode;        /* File's inode. */
     off_t pos;                  /* Current position. */
     bool deny_write;            /* Has file_deny_write() been called? */
   };



void
syscall_init (void) 
{
  readcount = 0;
  sema_init(&mutex, 1);
  sema_init(&wrt, 1);
  intr_register_int (0x30, 3, INTR_ON, syscall_handler, "syscall");
}

static void
syscall_handler (struct intr_frame *f) 
{
//	if((f->esp)==NULL)exit(-1); 
  switch(*(uint32_t *)(f->esp)) {
	case SYS_HALT :
		halt();
		break;
	case SYS_EXIT :
		if(!is_user_vaddr(f->esp + 4))	exit(-1);
		exit(*(uint32_t *)(f->esp + 4));
		break;
	case SYS_EXEC :
		if(!is_user_vaddr(f->esp + 4))	exit(-1);
		f->eax = exec((const char *)*(uint32_t *)(f->esp + 4));
		break;
	case SYS_WAIT :
		if(!is_user_vaddr(f->esp + 4))	exit(-1);
		f->eax = wait((pid_t)*(uint32_t *)(f->esp + 4));
		break;
	case SYS_CREATE : 
		if(!is_user_vaddr(f->esp + 4)) exit(-1);
		if(!is_user_vaddr(f->esp + 8)) exit(-1);
		f->eax = create((const char*)*(uint32_t*)(f->esp+4),(unsigned)*(uint32_t*)(f->esp+8));
		break;
	case SYS_REMOVE : 
		if(!is_user_vaddr(f->esp+4)) exit(-1);
		f->eax = remove((const char*)*(uint32_t*)(f->esp+4));
		break;
	case SYS_OPEN : 
		if(!is_user_vaddr(f->esp+4)) exit(-1);
		f->eax = open((const char*)*(uint32_t*)(f->esp+4));
		break;
	case SYS_FILESIZE :
		if(!is_user_vaddr(f->esp+4)) exit(-1);
		f->eax = filesize((unsigned)*(uint32_t*)(f->esp+4));
		break;
	case SYS_READ :
		if(!is_user_vaddr(f->esp + 4)||(f->esp+4)==NULL)	exit(-1);
		if(!is_user_vaddr(f->esp + 8)||(f->esp+8)==NULL)	exit(-1);
		if(!is_user_vaddr(f->esp + 12)||(f->esp+12)==NULL)	exit(-1);
		f->eax = read((int)*(uint32_t *)(f->esp+4), (void *)*(uint32_t *)(f->esp + 8), (unsigned)*((uint32_t *)(f->esp + 12)));
		break;
	case SYS_WRITE :
		if(!is_user_vaddr(f->esp + 4)) exit(-1);
		if(!is_user_vaddr(f->esp + 8)) exit(-1);
		if(!is_user_vaddr(f->esp + 12)) exit(-1);
		f->eax = write((int)*(uint32_t *)(f->esp+4), (void *)*(uint32_t *)(f->esp + 8), (unsigned)*((uint32_t *)(f->esp + 12)));
		break;
	case SYS_SEEK :
		if(!is_user_vaddr(f->esp + 4)) exit(-1);
		if(!is_user_vaddr(f->esp + 8)) exit(-1);
		seek((int)*(uint32_t*)(f->esp + 4), (unsigned)*(uint32_t*)(f->esp + 8));
		break;
	case SYS_TELL :
		if(!is_user_vaddr(f->esp + 4)) exit(-1);
		f->eax = tell((int)*(uint32_t *)(f->esp + 4));
		 break;
	case SYS_CLOSE : 
		if(!is_user_vaddr(f->esp + 4)) exit(-1);
		close((int)*(uint32_t*)(f->esp + 4));
		break;
	case SYS_FIBO : 
		if(!is_user_vaddr(f->esp+4)) exit(-1);
		f->eax = fibo(*(int*)(f->esp+4));
		break;
	case SYS_SUM :
		if(!is_user_vaddr(f->esp+8) || !is_user_vaddr(f->esp+12)) exit(-1);
		if(!is_user_vaddr(f->esp+16) || !is_user_vaddr(f->esp+4)) exit(-1);
		f->eax = sum(*(int*)(f->esp+4), *(int*)(f->esp+8), *(int*)(f->esp+12), *(int*)(f->esp+16));
  }
	

//  printf ("system call!\n");
//  thread_exit ();
}

void check_func (bool flag, int num, const char* str) {
	if(flag == true) {
		printf("%s : %d\n", str, num);
		exit(-1);
	}
}

void halt (void) {
	shutdown_power_off();
}

void exit (int status) {
	printf("%s: exit(%d)\n", thread_name(), status);
	
/*	int i;
	for( i=3;i<130;i++) {
		if(thread_current()->fd[i]==NULL) continue;
		close(i);
	}
*/
	thread_current() -> exit_status = status;
	int i;
     for( i=3;i<130;i++) {
         if(thread_current()->fd[i]==NULL) continue;
		close(i);
	 	 //thread_current()->fd[i] = NULL;
     }

	thread_exit();
}

pid_t exec (const char *cmd_line) {
	//printf("start\n");
	pid_t td= process_execute(cmd_line);
	return td;
}

int wait (pid_t pid) {
	return process_wait(pid);
}

int read (int fd, void* buffer, unsigned size) {
	int i, return_value;
	
//	if(fd==1||fd==2 || fd < 0) return -1;
	
	if(is_user_vaddr(buffer+size)==false)exit(-1);

	sema_down(&mutex);
	readcount++;
	if(readcount == 1)	sema_down(&wrt);
	sema_up(&mutex);

	if (fd == 0) {
		for ( i = 0; i < size; i++) {
			check_func(false, 1, "check");
			//((char*)buffer)[i]=input_getc();
			if(((char *)buffer)[i] == '\0') {
				break;
			}
		}
		return_value=i;
	}
	else if(fd>2){
		if(thread_current()->fd[fd] != NULL){
		//	printf("here");
		//	for(i=0;i<size;i++) printf("%c",*(char*)(buffer+i));
			return_value= file_read(thread_current()->fd[fd], buffer, size);
		}
		else if(thread_current()->fd[fd]==NULL){
			exit(-1);
		}
	}
	
	sema_down(&mutex);
	readcount--;
	if(readcount == 0)	sema_up(&wrt);
	sema_up(&mutex);

	return return_value;
	
}

int write (int fd, const void *buffer, unsigned size) {
	int return_value;

//	 if(fd==0||fd==2 || fd < 0) return -1;
	
     if(is_user_vaddr(buffer+size)==false)exit(-1);

	sema_down(&wrt);
	if (fd == 1) {
		check_func(false, 1, "check");
		putbuf(buffer, size);
		return_value= size;
	}
	else if(fd>2){
		if( thread_current()->fd[fd] != NULL){
			 return_value= file_write(thread_current()->fd[fd], buffer, size);
		}
		else if(thread_current()->fd[fd] == NULL) exit(-1);

	}

	else 
		return_value = -1;
	sema_up(&wrt);
	
	return return_value;
}

int fibo(int n) {
	if(n<=2) return 1;
	else return fibo(n-1) + fibo(n-2);
}

int sum(int n1, int n2, int n3, int n4) {
	return n1 + n2 + n3 + n4;
}


bool create(const char* file, unsigned initial_size) {
	if(file==NULL) exit(-1);
	return filesys_create(file, initial_size);	
}

bool remove(const char* file) {
	if(file==NULL) exit(-1);
	return filesys_remove(file);
}

int open(const char* file) {
	if(file==NULL) exit(-1);

	struct file* f = filesys_open(file);
	if(strcmp(thread_name(), file) == 0)	file_deny_write(f);
	
	if(f==NULL) return -1;
	int i;
	for(i=3;i<130;i++) {
		if(thread_current()->fd[i] == NULL) {
			thread_current()->fd[i] = f;
			return i;
		}	
	}
	return -1;
}

int filesize(int fd) {
	if(thread_current()->fd[fd]==NULL) exit(-1);
	return file_length(thread_current()->fd[fd]);
}

void seek(int fd, unsigned position) {
	if(thread_current()->fd[fd] == NULL) exit(-1);
	file_seek(thread_current()->fd[fd], position);
}

unsigned tell(int fd) {
	if(thread_current()->fd[fd]==NULL) exit(-1);
	return file_tell(thread_current()->fd[fd]);
}

void close(int fd) {
	if(thread_current()->fd[fd]==NULL) exit(-1);
	struct file* f = thread_current()->fd[fd];
	file_close(f);
	thread_current()->fd[fd] = NULL;
}
